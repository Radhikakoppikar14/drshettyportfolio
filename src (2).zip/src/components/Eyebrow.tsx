// Small section label with a short rainbow line.
export default function Eyebrow({ children, light = false, className = '' }: { children: React.ReactNode; light?: boolean; className?: string }) {
  return (
    <p className={`inline-flex items-center gap-3 text-[12px] font-semibold uppercase tracking-[0.2em] ${light ? 'text-muted-d' : 'text-muted'} ${className}`}>
      <span className="block w-7 h-[2px] rounded-full " style={{ background: 'linear-gradient(90deg,#0E9384,#3BA7E5,#E5484D)' }} aria-hidden="true" />
      {children}
    </p>
  );
}