import { useEffect, useRef, useState } from 'react';
import Button from './Button.tsx';
import Icon from './Icon.tsx';
import { bookingEndpoint, clinic, dental, heart } from '../data.ts';

type DeptKey = '' | 'dental' | 'heart';
type Status = 'idle' | 'sending' | 'sent' | 'manual' | 'error';

const DEPTS = { dental, heart } as const;
const GENERAL = 'General consultation / not sure yet';

// Works out which department and treatment an "Ask about this" / "Book" click was about.
// `topic` is either a treatment title (e.g. "Braces & TMJ Therapy") or text like "Heart Care appointment".
function derive(topic: string): { dept: DeptKey; service: string } {
  for (const k of ['dental', 'heart'] as const) {
    if (DEPTS[k].services.some((s) => s.t === topic)) return { dept: k, service: topic };
  }
  if (/dental/i.test(topic)) return { dept: 'dental', service: '' };
  if (/heart|cardi/i.test(topic)) return { dept: 'heart', service: '' };
  return { dept: '', service: '' };
}

const today = () => new Date().toISOString().slice(0, 10);

export default function Booking({ open, onClose, topic }: { open: boolean; onClose: () => void; topic: string }) {
  const [status, setStatus] = useState<Status>('idle');
  const [dept, setDept] = useState<DeptKey>(() => derive(topic).dept);
  const [service, setService] = useState(() => derive(topic).service);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [message, setMessage] = useState('');
  const first = useRef<HTMLInputElement>(null);
  const close = () => { setStatus('idle'); onClose(); };

  // every time the form opens, start from what the visitor clicked on
  useEffect(() => {
    if (!open) return;
    const d = derive(topic);
    setDept(d.dept);
    setService(d.service);
    setStatus('idle');
  }, [open, topic]);

  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    document.body.style.overflow = 'hidden';
    const t = window.setTimeout(() => first.current?.focus(), 60);
    const k = (e: KeyboardEvent) => e.key === 'Escape' && close();
    window.addEventListener('keydown', k);
    return () => { window.clearTimeout(t); document.body.style.overflow = ''; window.removeEventListener('keydown', k); prev?.focus?.(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  if (!open) return null;

  const deptLabel = dept ? DEPTS[dept].label : '';
  const services = dept ? [...DEPTS[dept].services.map((s) => s.t), GENERAL] : [];
  const purpose = [deptLabel, service].filter(Boolean).join(' – ');
  const payload = { department: deptLabel, treatment: service || GENERAL, name: name.trim(), phone: phone.trim(), preferredDate: date, message: message.trim() };
  const mailto = (() => {
    const subject = `Appointment request – ${purpose || 'General'}`;
    const body = [
      `Department: ${payload.department}`,
      `Treatment / reason: ${payload.treatment}`,
      `Name: ${payload.name}`,
      `Phone: ${payload.phone}`,
      `Preferred date: ${payload.preferredDate || 'Not specified'}`,
      `Message: ${payload.message || '-'}`,
    ].join('\n');
    return `mailto:${clinic.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  })();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingEndpoint) { setStatus('manual'); return; }
    setStatus('sending');
    try {
      const r = await fetch(bookingEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload) });
      setStatus(r.ok ? 'sent' : 'error');
    } catch {
      setStatus('error');
    }
  };

  const f = 'w-full h-12 rounded-xl ring-1 ring-inset ring-line bg-paper px-4 text-[15px] text-text placeholder:text-muted/70 focus:outline-none focus:ring-2 focus:ring-[var(--acc)] transition';
  const label = 'block text-[12px] font-medium text-muted mb-1.5';
  const done = status === 'sent' || status === 'manual';
  return (
    <div className="fixed inset-0 z-[80] bg-ink/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 fade-in" onClick={close} role="dialog" aria-modal="true" aria-labelledby="booking-title">
      <div className="pop-in relative w-full sm:max-w-md bg-white rounded-t-[2rem] sm:rounded-[2rem] overflow-hidden max-h-[92svh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="h-1.5" style={{ background: 'var(--grad-btn)' }} />
        <button onClick={close} aria-label="Close" className="absolute top-4 right-4 w-10 h-10 rounded-full bg-paper text-muted hover:text-ink flex items-center justify-center"><Icon name="X" /></button>
        <div className="p-6 sm:p-8">
          {done ? (
            <div className="py-2">
              <span className="w-14 h-14 rounded-full bg-acc-soft t-acc flex items-center justify-center"><Icon name="Check" className="w-7 h-7" stroke={2.2} /></span>
              <h3 id="booking-title" className="mt-5 text-3xl text-ink">{status === 'sent' ? 'Thank you' : 'One last step'}</h3>
              <p className="text-muted mt-2 text-sm">
                {status === 'sent' ? 'We have received your request and will call you to confirm.' : 'Send your request to the clinic by email, or call us to book right away.'}
              </p>
              <dl className="mt-5 rounded-2xl bg-paper ring-1 ring-line p-4 text-sm grid grid-cols-[auto_1fr] gap-x-4 gap-y-2">
                <dt className="text-muted">Department</dt><dd className="text-ink font-medium">{payload.department}</dd>
                <dt className="text-muted">Treatment</dt><dd className="text-ink font-medium">{payload.treatment}</dd>
                <dt className="text-muted">Name</dt><dd className="text-ink">{payload.name}</dd>
                <dt className="text-muted">Phone</dt><dd className="text-ink">{payload.phone}</dd>
                <dt className="text-muted">Date</dt><dd className="text-ink">{payload.preferredDate || 'Not specified'}</dd>
              </dl>
              <div className="mt-6 flex flex-col gap-3">
                {status === 'manual' && <Button href={mailto} icon="Mail" arrow>Email this request</Button>}
                <Button href={clinic.tel} icon="Phone" variant={status === 'manual' ? 'outline' : 'primary'}>Call {clinic.phone}</Button>
                <Button onClick={close} variant="outline">Close</Button>
              </div>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-3">
              <h3 id="booking-title" className="text-3xl text-ink pr-10">Book an Appointment</h3>
              {purpose && (
                <p className="inline-flex items-center gap-2 rounded-full bg-acc-soft t-acc px-3 py-1 text-xs font-medium"><Icon name="CalendarCheck" className="w-3.5 h-3.5" />{purpose}</p>
              )}
              <div>
                <label htmlFor="bk-dept" className={label}>Appointment for</label>
                <div className="relative">
                  <select id="bk-dept" required value={dept} onChange={(e) => { setDept(e.target.value as DeptKey); setService(''); }} className={`${f} appearance-none pr-10`}>
                    <option value="" disabled>Select Dental or Heart care</option>
                    <option value="dental">Dental Care</option>
                    <option value="heart">Heart Care</option>
                  </select>
                  <Icon name="ChevronDown" className="w-4 h-4 text-muted absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>
              <div>
                <label htmlFor="bk-service" className={label}>Treatment / reason</label>
                <div className="relative">
                  <select id="bk-service" required disabled={!dept} value={service} onChange={(e) => setService(e.target.value)} className={`${f} appearance-none pr-10 disabled:opacity-60`}>
                    <option value="" disabled>{dept ? 'Select a treatment' : 'Choose a department first'}</option>
                    {services.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                  <Icon name="ChevronDown" className="w-4 h-4 text-muted absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>
              <input ref={first} required value={name} onChange={(e) => setName(e.target.value)} aria-label="Full name" placeholder="Full name" autoComplete="name" className={f} />
              <input required type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} aria-label="Phone" placeholder="Phone number" autoComplete="tel" className={f} />
              <input type="date" min={today()} value={date} onChange={(e) => setDate(e.target.value)} aria-label="Preferred date" className={f} />
              <textarea value={message} onChange={(e) => setMessage(e.target.value)} aria-label="Message" placeholder="How can we help? (optional)" rows={3} className={`${f} h-auto py-3`} />
              {status === 'error' && (
                <p role="alert" className="text-sm text-coral-ink">We could not send that just now. Please try again, or <a className="underline" href={mailto}>email us</a> or call {clinic.phone}.</p>
              )}
              <Button type="submit" arrow className="w-full">{status === 'sending' ? 'Sending…' : 'Request Appointment'}</Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}