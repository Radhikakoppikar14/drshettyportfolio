import Icon from './Icon.tsx';
import Reveal from './Reveal.tsx';

// Short brand statement band (moved here from the footer). Two lines, second one in the page accent.
export default function Statement({ lines, onBook }: { lines: [string, string]; onBook: () => void }) {
  return (
    <section aria-label="Our promise" className="bg-paper py-8 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <Reveal>
          <p className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight leading-[1.06] text-ink max-w-2xl">
            {lines[0]}<br /><span className="gt-light">{lines[1]}</span>
          </p>
        </Reveal>
        <Reveal delay={120}>
          <button onClick={onBook} className="group inline-flex items-center gap-3 text-lg font-medium text-ink">
            <span className="link-u">Book an appointment</span>
            <span className="w-12 h-12 rounded-full btn-grad text-white flex items-center justify-center transition-transform duration-300 group-hover:rotate-45"><Icon name="ArrowUpRight" /></span>
          </button>
        </Reveal>
      </div>
    </section>
  );
}