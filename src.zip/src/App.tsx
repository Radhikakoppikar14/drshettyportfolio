import Home from './pages/Home.tsx';
import SitePage from './pages/sitePage.tsx';
import { dental, heart } from './data.ts';
import { useRoute } from './router.ts';

// 3 views: common home page (#/), heart care website (#/heart), dental care website (#/dental).
export default function App() {
  const route = useRoute();
  if (route === 'heart') return <SitePage key="heart" d={heart} />;
  if (route === 'dental') return <SitePage key="dental" d={dental} />;
  return <Home />;
}